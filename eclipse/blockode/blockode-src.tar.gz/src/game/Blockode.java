/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import org.bukkit.Bukkit;
import static org.bukkit.Bukkit.getLogger;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/**
 *
 * @author HXB
 */
public final class Blockode implements Listener{
    
    String []PlayerList;
    private EffectExec executer;
    int PlayerNumber=0;//减一之后再使用
    private int MaximumPlayer=12;//最多12个人
    private int ExplodeSize=4;
    private int Wall_Size_X=3;
    private int Wall_Size_Y=3;
    private int shieldDelay=1;
    float shieldHold=4;
    int TNTdelay=2;
    private World gameworld;
    private HashMap<String, ItemStack[]> mySavedItems = new HashMap<String, ItemStack[]>();//玩家物品
    private HashMap<String, ItemStack[]> mySavedArmors = new HashMap<String, ItemStack[]>();//玩家盔甲
    private int amountBeacon=1,
            amountBed=1,
            amountBow=1,
            amountArrow=1,
            amountBread=1,
            amountTNT=1,
            amountIronSward=1;
    private ItemStack[] gameItems;


    public Blockode(){
        System.out.print("[breaksense()]");
        PlayerList=new String[this.MaximumPlayer];
    }
    
    static public void test(){
        System.out.print("[test()]");
    }

   public boolean addtoPlayerList(Player player){
       String name=player.getName();
        if (PlayerNumber>=MaximumPlayer) {return false;}//人数超过则返回错误
       else {
           if(isInList(name)==false){
               this.PlayerList[PlayerNumber]=name;
               initPlayer(player);
               getLogger().info("玩家:"+name+"已被添加至游戏列表。");
               //Bukkit.getPlayer(name).sendMessage("玩家:"+name+"已被添加至游戏列表。");
               PlayerNumber++;
               return true;
           }//不然就把名单上面下一位给加上传过来的玩家
           else{
              getLogger().info("玩家"+name+"已存在列表中");
              Bukkit.getPlayer(name).sendMessage("玩家"+Bukkit.getPlayer(name)+"已存在列表中");
             return false;
           }
       }
   }
   
   
      public boolean addtoPlayerList(String name){
        if (PlayerNumber>=MaximumPlayer) {return false;}//人数超过则返回错误
        if(Bukkit.getPlayer(name)==null){
            System.out.print("玩家都不存在，你还添加");
            return false;
        }
        else{
            return this.addtoPlayerList(Bukkit.getPlayer(name));
        }
   }
   
   
   @SuppressWarnings("deprecation")
public boolean removefromPlayerList(Player player){
       //getLogger().info("开始查询玩家");
       if(!isInList(player)){
           getLogger().info("找不到玩家");
           return false;
       }
       else{
           //getLogger().info("确认玩家在列表内，开始搜索");
    	 //下面是移过来到内容：
           System.out.print("执行到玩家"+player.getName());
           Damageable playerdg=(Damageable)player;
           //player.getInventory().setContents(this.mySavedItems.get(player.getName()));//回复背包
           //player.getInventory().setArmorContents(this.mySavedArmors.get(player.getName()));
           player.setWalkSpeed(0.2f);//状态再次归零
           player.setMaxHealth(20);
           player.setFoodLevel(20);
           player.setExp(0);
           player.eject();
           player.setHealth(playerdg.getMaxHealth());
           for(PotionEffect effect : player.getActivePotionEffects())//清空药水效果
           {
             player.removePotionEffect(effect.getType());
           }
           player.teleport(gameworld.getSpawnLocation());//传送进等待区
           this.recoverBackpack(player.getName());//改进后的回复背包
           
           System.out.print("执行完玩家"+player.getName());
           //上面是移过来到内容
           
           int a=0;
           for(String name : PlayerList){
           getLogger().info("removefromPlayerList():匹配"+player.getName()+"第"+(a+1)+"次");
           if(name.equals(player.getName())) {
               //player.getInventory().setContents(this.mySavedItems.get(PlayerList[i]));//回复背包
               //player.getInventory().setArmorContents(this.mySavedArmors.get(PlayerList[i]));
               //initPlayer(player);
               this.PlayerList[a]=null; 
               this.PlayerNumber=this.PlayerNumber-1;
               return true;
               }
           a++;
             }
            }
              getLogger().info("未知错误"); 
              return false;
   }
   
   public boolean removefromPlayerList(String name){
       if(Bukkit.getPlayer(name)==null){
            System.out.print("玩家都不存在，肯定不在列表内");
            return false;
        }
       if(!isInList(name)){
           getLogger().info("找不到玩家,移除什么");
           return false;
       }
        else{
            return this.removefromPlayerList(Bukkit.getPlayer(name));
        }
   }
   
   public void clearPlayerList(){
        for(int i=0;i<12;i++){
           this.PlayerList[i]=" ";
       }
    }
   
   public boolean isInList(Player player){
       for(int i=0;i<=(PlayerNumber-1);i++){
           //getLogger().info("匹配"+player.getName()+"第"+(i+1)+"次");
           if(this.PlayerList[i].equals(player.getName())&&this.gameworld.equals(player.getWorld())) {
               //getLogger().info("匹配到列表中是玩家");
               return true;
           }
       }
       return false;
   }
   
    public boolean isInList(String name){
        if(Bukkit.getPlayer(name)==null){
            System.out.print("玩家都不存在，肯定不在列表内");
            return false;
        }
        else{
            return this.isInList(Bukkit.getPlayer(name));
        }
   }
      @SuppressWarnings("deprecation")
	public void initPlayer(String name){
          Player player;
          Damageable playerdg;
          if(Bukkit.getPlayer(name)!=null){
            player=Bukkit.getPlayer(name);
            playerdg=(Damageable)player;
          }
          else{
              System.out.print("玩家不存在，初始化个屁啊。。");
              return;
          }
          player.setWalkSpeed(0.2f);
          player.setMaxHealth(20);
          player.setFoodLevel(20);
          player.setExp(0);
          player.eject();
          player.setHealth(playerdg.getMaxHealth());
          for(PotionEffect effect : player.getActivePotionEffects())//清空药水效果
          {
            player.removePotionEffect(effect.getType());
          }
          player.teleport(gameworld.getSpawnLocation());//传送进等待区
          
          ItemStack[] inventory=player.getInventory().getContents();//保存背包信息
          this.mySavedItems.put(player.getName(), inventory);
          this.mySavedArmors.put(player.getName(), player.getInventory().getArmorContents());
          
          player.getInventory().clear();//清空背包
          PlayerInventory inv = player.getInventory();
          inv.setHelmet(new ItemStack(Material.AIR));
          inv.setChestplate(new ItemStack(Material.AIR));
          inv.setLeggings(new ItemStack(Material.AIR));
          inv.setBoots(new ItemStack(Material.AIR));//到这里就清空了
          

          
          
      }
      
      public void initPlayer(Player player){
            this.initPlayer(player.getName());
      }
      
      public void recoverBackpack(String name){
    	  Player player=Bukkit.getPlayer(name);
    	  ItemStack[] items=this.mySavedArmors.get(name);
    	  player.getInventory().setContents(this.mySavedItems.get(name));//回复背包
          player.getInventory().setArmorContents(this.mySavedArmors.get(name));
          
          System.out.print("已回复"+name+"的"+items.length);
      }
      
    public void start(){
        for(int i=0;i<PlayerList.length;i++){
            Player player;
            if(PlayerList[i]!=null&&Bukkit.getPlayer(PlayerList[i])!=null){//开始命令时需要执行的内容(现在的应该结束时运行，仅为调试方便放在了这里)
            	player=Bukkit.getPlayer(PlayerList[i]);
            	PlayerInventory inv = player.getInventory();
            	gameItems = new ItemStack[]{new ItemStack(Material.ARROW,this.amountArrow),//更新实时的配置文件设置
            	        new ItemStack(Material.BEACON,this.amountBeacon),
            	        new ItemStack(Material.BED,this.amountBed),
            	        new ItemStack(Material.BOW,this.amountBow),
            	        new ItemStack(Material.BREAD,this.amountBread),
            	        new ItemStack(Material.TNT,this.amountTNT),
            	        new ItemStack(Material.IRON_SWORD,this.amountIronSward)
            	    };
            	inv.addItem(gameItems);//加入设定物品
            }
            else if(PlayerList[i]!=null){//玩家已经下线的话
                Bukkit.broadcastMessage(ChatColor.BLUE+"[Blockode]玩家:"+PlayerList[i]+"找不到了，所以没加入游戏");
            }
        }
        Bukkit.broadcastMessage(ChatColor.BLUE+"初始化完成，游戏开始！");
    }
    
    @SuppressWarnings("deprecation")
	public void stop(){//停止命令时需要执行的内容
        for(int i=0;i<PlayerList.length;i++){
            Player player;
            Damageable playerdg;
            if(PlayerList[i]!=null&&Bukkit.getPlayer(PlayerList[i])!=null){//停止命令时需要执行的内容(现在的应该结束时运行，仅为调试方便放在了这里)（现在放这里挺好的）
                System.out.print("执行到玩家"+PlayerList[i]);
                player=Bukkit.getPlayer(PlayerList[i]);
                playerdg=(Damageable)player;
                //player.getInventory().setContents(this.mySavedItems.get(PlayerList[i]));//回复背包
                //player.getInventory().setArmorContents(this.mySavedArmors.get(PlayerList[i]));
                this.recoverBackpack(PlayerList[i]);
                
                player.setWalkSpeed(0.2f);//状态再次归零
                player.setMaxHealth(20);
                player.setFoodLevel(20);
                player.setExp(0);
                player.eject();
                player.setHealth(playerdg.getMaxHealth());
                for(PotionEffect effect : player.getActivePotionEffects())//清空药水效果
                {
                  player.removePotionEffect(effect.getType());
                }
                player.teleport(gameworld.getSpawnLocation());//传送进等待区
                
                System.out.print("执行完玩家"+PlayerList[i]);
            }
            else if(PlayerList[i]!=null&&PlayerList[i]!=""&&PlayerList[i]!=" "){//玩家下线的话
                Bukkit.broadcastMessage(ChatColor.BLUE+"[Blockode]玩家:"+PlayerList[i]+"找不到了，所以没加入游戏");
            }
        }
        this.clearPlayerList();
        Bukkit.broadcastMessage(ChatColor.BLUE+"游戏已结束!");
    }
    
//监听器放置
	@EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)  //这就是我说的那个监听器了，事件发生时会触发下面这个方法
	public void onBlockPlace(BlockPlaceEvent e)  {
	    //int x=e.getBlock().getX(),
	    //    y=e.getBlock().getY(),
	    //    z=e.getBlock().getZ();
	    //Location playerLocation=e.getPlayer().getLocation(),
	    //         blockLocation=e.getBlock().getLocation();
	    
	    //方块信标,制造一面墙和冲击
	    if(e.getBlock().getType() == Material.BEACON){
	        if(isInList(e.getPlayer())==true){//如果发出者在列表里，就执行下面的内容（单独执行不会报错，工作正常）
	            EffectExec shield=new EffectExec(shieldHold);
	            e.getPlayer().sendMessage(ChatColor.BLUE+"按住\"S\"以充能...按得越久护盾距离越远哦");
	            shield.SheildEnterence(e,shieldDelay);
	            shield=null;//即时释放内存。。
	            return;
	        }
	    }
	    //貌似上面那个加上去之后下面这个就废了。。（已解决，我眼瞎了）
	    
	    //方块TNT,爆炸
	    if(e.getBlock().getType() == Material.TNT){  
	        if(isInList(e.getPlayer())==true){//如果发出者在列表里，就执行下面的内容（单独执行不会报错，工作正常）(连续使用会无法传递事件，是getspeed/setpseed的问题)
	            EffectExec TNT=new EffectExec(ExplodeSize);
	            TNT.setExplodePower(ExplodeSize);
	            TNT.setTNTdelay(TNTdelay);
	            TNT.ChargeTNT(e);
	            TNT=null;//释放内存
	            //getLogger().info(ChatColor.GREEN+e.getPlayer().toString()+"在"+e.getBlock().getLocation()+"放置了"+e.getBlock()+"并且炸了");
	            return;  
	       }
	        return;
	    }
	
	    return;
	}

	//射箭监听器使用
    @EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)  //这就是我说的那个监听器了，事件发生时会触发下面这个方法
    public void onEntityShootBow(final EntityShootBowEvent e)  {
        //把人挂上去
        if(e.getEntity() instanceof Player&&isInList((Player)e.getEntity())){
            e.getProjectile().setVelocity(e.getProjectile().getVelocity().add(e.getProjectile().getVelocity()));
            e.getProjectile().setPassenger(e.getEntity());
            
            new BukkitRunnable(){//效果播放
                int timemax=15;
                @Override
                public void run(){
                    timemax=timemax-1;
                    if(timemax<=0){
                        cancel();
                    }
                    //boolean exist=false;
                    //System.out.print("effect,enter");
                    /*for(Entity entity : e.getProjectile().getNearbyEntities(2d, 2d, 2d)){
                        if(entity instanceof Projectile){
                            exist=true;
                        }
                    }*/
                    //if(!e.getProjectile().isOnGround()|!e.getEntity().isOnGround()){
                    if(Material.AIR==e.getProjectile().getWorld().getBlockAt((int)e.getProjectile().getLocation().getX(), (int)e.getProjectile().getLocation().getY()-1, (int)e.getProjectile().getLocation().getZ()).getType()){
                        for(int i=0;i<10;i++){
                            e.getProjectile().getWorld().playEffect(e.getProjectile().getLocation(), Effect.FIREWORKS_SPARK, 2);
                            //Material m=e.getProjectile().getWorld().getBlockAt((int)e.getProjectile().getLocation().getX(), (int)e.getProjectile().getLocation().getY()-1, (int)e.getProjectile().getLocation().getZ()).getType();
                            //System.out.print(m.name()+",effect,"+e.getEntity().isOnGround());
                        }
                    }
                    else{
                        cancel();
                    }
                }
            }.runTaskTimer(Bukkit.getPluginManager().getPlugin("blockode"), 10L, 2L);
            
            new BukkitRunnable(){//确认不会卡在墙里面
            //int a=0;
            @Override
            public void run() {
                /*if(e.getEntity().getLocation().getBlock().getType()!=Material.AIR){//防止困住
                    //System.out.print("一次执行");
                    e.getEntity().eject();
                    e.getProjectile().eject();
                    e.getEntity().getLocation().setY(e.getEntity().getLocation().getY()+3);
                    if(e.getEntity().getLocation().getBlock().getType()==Material.AIR){
                        needdo=true;
                    }
                    isdo=true;
                    }
                    if(isdo==true&&needdo==true){
                        System.out.print("全部完了isdo:"+isdo+",needdo:"+needdo);
                        cancel();
                    }*///解决方案1
                if(e.getEntity().getLocation().getBlock().getType()!=Material.AIR||e.getProjectile().getVelocity()==new Vector(0,0,0)){
                    //System.out.print("eject");
                    e.getEntity().eject();
                    e.getProjectile().eject();
                    e.getProjectile().remove();
                    Location loc=e.getEntity().getLocation();
                    loc.setY(e.getEntity().getLocation().getY()+1);
                    e.getEntity().teleport(loc);
                    if(e.getEntity().getLocation().getBlock().getType()==Material.AIR){
                        cancel();
                    }
                }//解决方案2
                
            }
        }.runTaskTimer(Bukkit.getPluginManager().getPlugin("blockode"), 10L, 2L);
            return;
        }
    }
    
    //命中监听器使用
    @EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)
    public void OnProjectileHit(ProjectileHitEvent e){
        //if(e.getEntity().getPassenger()!=null && isInList((Player)e.getEntity().getPassenger())){
            //e.getEntity().getPassenger().setVelocity(e.getEntity().getVelocity());
        //}
        
    }
    
    //受伤监听器使用
    @EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)
    public void OnPlayerDamage(EntityDamageEvent e){
        //if(e.getEntity() instanceof Player && isInList((Player)e.getEntity())&&){
            //e.getEntity().getPassenger().setVelocity(e.getEntity().getVelocity());
        //}
    }
    
    //被射中受伤监听器使用
    @SuppressWarnings("deprecation")
	@EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)//确认不会把自己射中
    public void OnEntityDamageByEntity(EntityDamageByEntityEvent e){
    	//System.out.print("监听到了被射中事件:\ndamager:"+e.getDamager().getType().toString()+
    		//			"\n entityType:"+e.getEntityType().toString()+
    			//		"\n entity:"+e.getEntity());
        if (e.getDamager() != null//找得到伤害者
                && e.getDamager().getType() == EntityType.ARROW//是箭
                && ((Arrow) e.getDamager()).getShooter() instanceof Player//射击者是玩家
                && e.getEntityType() == EntityType.PLAYER //被击中者是玩家
                && isInList((Player)((Arrow) e.getDamager()).getShooter())//发出者在列表中
                && isInList((Player)e.getEntity())//被击中者在列表中
                && ((Arrow) e.getDamager()).getShooter() == e.getEntity()//是自己发出的
                ) {
            //e.getEntity().setVelocity(e.getDamager().getVelocity());
        	//System.out.print("监听到了被射中事件2");
            ((Player)e.getEntity()).sendMessage(ChatColor.RED+"你已达到最大射程，为了免得你摔死，你正在降落");
            e.setCancelled(true);
        }
    }
    
    //进入床监听器使用
    @EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)  //这就是我说的那个监听器了，事件发生时会触发下面这个方法
    public void onBedEnter(final PlayerBedEnterEvent e)  {
        new BukkitRunnable(){//保证晚上
                @Override
                public void run(){
                    gameworld.setTime(111111);
                };
            }.runTaskTimer(Bukkit.getPluginManager().getPlugin("blockode"), 0L, 200L);
        
        final Damageable playerdg=(Damageable)e.getPlayer();
        if(isInList(e.getPlayer()) && playerdg.getHealth()<playerdg.getMaxHealth()){//回血
            new BukkitRunnable(){
                @Override
                public void run(){
                    if(playerdg.getHealth()<playerdg.getMaxHealth()&&e.getPlayer().isSleeping()){
                        e.getPlayer().setHealth(playerdg.getHealth()+6);
                    }
                    else{
                        //e.getPlayer().teleport(e.getPlayer().getLocation());
                        ((CraftPlayer) e.getPlayer()).getHandle().a(true, false, false);
                        e.getBed().setType(Material.AIR);
                        cancel();
                            };
                }
            }.runTaskTimer(Bukkit.getPluginManager().getPlugin("blockode"), 20L, 20L);
        }
        else{
            return;
        }
    }
    
    //传送监听器使用，除op外不允许传送
    @EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)  //这就是我说的那个监听器了，事件发生时会触发下面这个方法
    public void onPlayerTeleport(PlayerTeleportEvent e)  {
        if(this.isInList(e.getPlayer())&&!e.getTo().getWorld().equals(this.gameworld)&&!e.getPlayer().isOp()){//里面的人试图出去（op例外）
            e.getPlayer().sendMessage("你还在游戏中，不能出去！");
            e.setCancelled(true);
        }
        if(!this.isInList(e.getPlayer())&&e.getTo().getWorld().equals(this.gameworld)&&!e.getPlayer().isOp()){//外面的人试图进来(op例外)
            e.getPlayer().sendMessage("你不在游戏中，不能进来");
            e.setCancelled(true);
        }
    }
    
    //死亡监听器使用，自动重生
    @EventHandler(priority = EventPriority.NORMAL,ignoreCancelled = true)  //这就是我说的那个监听器了，事件发生时会触发下面这个方法
    public void onPlayerDeath(PlayerDeathEvent e)  {
    	final Player p=(Player)e.getEntity();
    	final Damageable dg=p;
    	//if(e.getEntity().getKiller().getDisplayName()!=null && e.getEntity().getDisplayName()!=null){//死亡信息
        //	e.setDeathMessage(ChatColor.BLUE+e.getEntity().getDisplayName()+ChatColor.RED+"被"+ChatColor.YELLOW+e.getEntity().getKiller().getDisplayName()+ChatColor.RED+"出局了!");
    	//}
    	//else{
    	//	e.setDeathMessage(ChatColor.RED+e.getEntity().getDisplayName()+"出局了！");
    	//}

    	while(p.getWorld().getSpawnLocation().getBlock().getType()!=Material.AIR){//确保不会出现在墙里面
    		p.getWorld().setSpawnLocation((int)p.getWorld().getSpawnLocation().getX(),(int)p.getWorld().getSpawnLocation().getY()+1,(int)p.getWorld().getSpawnLocation().getZ());
    		System.out.print("检测到重生点在方块内部，自动提升一格当前方块："+p.getWorld().getSpawnLocation().getBlock().getType().toString());
    	}
		p.setHealth(dg.getMaxHealth());
    	p.teleport(p.getWorld().getSpawnLocation());
    	this.removefromPlayerList(e.getEntity());
    	new BukkitRunnable(){
            @Override
            public void run() {
            		
            		cancel();
            }
        }.runTaskTimer(Bukkit.getPluginManager().getPlugin("blockode"), 8L, 2L);
            		
    	/*Bukkit.getScheduler().scheduleSyncDelayedTask(Bukkit.getPluginManager().getPlugin("blocode"), new Runnable() {
            @Override
            public void run() {
            	try {
                    Object nmsPlayer = p.getClass().getMethod("getHandle").invoke(p);
                    Object packet = Class.forName("net.minecraft.server." + Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3] + ".Packet205ClientCommand").newInstance();
                    packet.getClass().getField("a").set(packet, 1);
                    Object con = nmsPlayer.getClass().getField("playerConnection").get(nmsPlayer);
                    con.getClass().getMethod("a", packet.getClass()).invoke(con, packet);
                } 
            	catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        }, 8L); */
    }
    
    public static String exec(String command){//指令执行器。。。别的包里面复制进来的，倒包太麻烦，只需要一个方法（现在有卡死问题，那个插件里面修复完了，这里反正没用懒得修）
        try {  
                // 执行 CMD 命令  
               String output="=====开始执行=====";
               Process process = Runtime.getRuntime().exec(command);  
               // 从输入流中读取文本  
              BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));  
              String line = null;  
              // 循环读取  
               while ((line = reader.readLine()) != null) {  
                  // 循环写入  
                  System.out.print(line+"\n");
                  output=output+"\n"+line;
               }
              process.getOutputStream().close();
              System.out.println("程序执行完毕!");  
              return output;
            }
            catch (Exception e) {  
                e.printStackTrace();  
            }
        return ChatColor.RED+"哪里出错了";
    }
    
    /*//下面是抄来的。。
    public void saveInventory(Player player){
        this.mySavedItems.put(player.getName(), copyInventory(player.getInventory()));
    }
    /**
    * This removes the saved inventory from our HashMap, and restores it to the player if it existed.
    * @return true if success
    
    public boolean restoreInventory(Player player){
        ItemStack[] savedInventory = this.mySavedItems.remove(player.getName());
        if(savedInventory == null)
            return false;
        restoreInventory(player, savedInventory);
        return true;
    }
 
    private ItemStack[] copyInventory(Inventory inv){
        ItemStack[] original = inv.getContents();
        ItemStack[] copy = new ItemStack[original.length];
        for(int i = 0; i < original.length; ++i)
        if(original[I] !=[/I] null)
        copy = new ItemStack(original);
        return copy;
    }
 
    private void restoreInventory(Player p, ItemStack[] inventory){
        p.getInventory().setContents(inventory);
    }
*/
//下面是getter和setter

    public float getShieldHold() {
	    return shieldHold;
	}

	public int getTNTdelay() {
        return TNTdelay;
    }

    public void setShieldHold(float shieldHold) {
	    this.shieldHold = shieldHold;
	}

	public void setTNTdelay(int TNTdelay) {
        this.TNTdelay = TNTdelay;
    }

    public void setPlayerList(String[] PlayerList) {
        this.PlayerList = PlayerList;
    }

    public void setPlayerNumber(int PlayerNumber) {
        this.PlayerNumber = PlayerNumber;
    }

    public void setExplodeSize(int ExplodeSize) {
        this.ExplodeSize = ExplodeSize;
    }

    public int getMaximumPlayer() {
        return MaximumPlayer;
    }

    public int getExplodeSize() {
        return ExplodeSize;
    }
    
        
   public void setMaximumPlayer(int number){
       MaximumPlayer=number;
       PlayerList=new String[this.MaximumPlayer];
   }
   
   public int getPlayerNumber(){
       return PlayerNumber;
   }
   
   public String []getPlayerList(){
       return PlayerList;
   }

    public int getWall_Size_X() {
        return Wall_Size_X;
    }

    public int getWall_Size_Y() {
        return Wall_Size_Y;
    }

    public void setWall_Size_X(int Wall_Size_X) {
        this.Wall_Size_X = Wall_Size_X;
    }

    public void setWall_Size_Y(int Wall_Size_Y) {
        this.Wall_Size_Y = Wall_Size_Y;
    }

    public EffectExec getExecuter() {
        return executer;
    }

    public int getShieldDelay() {
        return shieldDelay;
    }

    public void setExecuter(EffectExec executer) {
        this.executer = executer;
    }

    public void setShieldDelay(int shieldDelay) {
        this.shieldDelay = shieldDelay;
    }

    public World getGameworld() {
        return gameworld;
    }

    public void setGameworld(World gameworld) {
        this.gameworld = gameworld;
    }

    public HashMap<String, ItemStack[]> getMySavedItems() {
        return mySavedItems;
    }

    public void setMySavedItems(HashMap<String, ItemStack[]> mySavedItems) {
        this.mySavedItems = mySavedItems;
    }

    public HashMap<String, ItemStack[]> getMySavedArmors() {
        return mySavedArmors;
    }

    public void setMySavedArmors(HashMap<String, ItemStack[]> mySavedArmors) {
        this.mySavedArmors = mySavedArmors;
    }

    public int getAmountBeacon() {
        return amountBeacon;
    }

    public void setAmountBeacon(int amountBeacon) {
        this.amountBeacon = amountBeacon;
    }

    public int getAmountBed() {
        return amountBed;
    }

    public void setAmountBed(int amountBed) {
        this.amountBed = amountBed;
    }

    public int getAmountBow() {
        return amountBow;
    }

    public void setAmountBow(int amountBow) {
        this.amountBow = amountBow;
    }

    public int getAmountArrow() {
        return amountArrow;
    }

    public void setAmountArrow(int amountArrow) {
        this.amountArrow = amountArrow;
    }

    public int getAmountBread() {
        return amountBread;
    }

    public void setAmountBread(int amountBread) {
        this.amountBread = amountBread;
    }

    public int getAmountTNT() {
        return amountTNT;
    }

    public void setAmountTNT(int amountTNT) {
        this.amountTNT = amountTNT;
    }

    public int getAmountIronSward() {
        return amountIronSward;
    }

    public void setAmountIronSward(int amountIronSward) {
        this.amountIronSward = amountIronSward;
    }

    public ItemStack[] getItems() {
        return gameItems;
    }

    public void setItems(ItemStack[] items) {
        this.gameItems = items;
    }
   

}
