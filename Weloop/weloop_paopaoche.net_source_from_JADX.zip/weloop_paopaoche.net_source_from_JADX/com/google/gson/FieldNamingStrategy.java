package com.google.gson;

import java.lang.reflect.Field;

/* compiled from: ProGuard */
public interface FieldNamingStrategy {
    String translateName(Field field);
}
