package com.google.gson.internal;

/* compiled from: ProGuard */
public interface ObjectConstructor<T> {
    T construct();
}
