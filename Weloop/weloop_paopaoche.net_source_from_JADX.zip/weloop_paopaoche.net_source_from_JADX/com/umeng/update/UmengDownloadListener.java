package com.umeng.update;

/* compiled from: ProGuard */
public interface UmengDownloadListener {
    void OnDownloadEnd(int i, String str);

    void OnDownloadStart();

    void OnDownloadUpdate(int i);
}
