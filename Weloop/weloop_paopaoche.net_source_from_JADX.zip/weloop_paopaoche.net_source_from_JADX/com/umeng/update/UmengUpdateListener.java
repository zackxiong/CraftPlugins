package com.umeng.update;

/* compiled from: ProGuard */
public interface UmengUpdateListener {
    void onUpdateReturned(int i, UpdateResponse updateResponse);
}
