package com.umeng.update;

/* compiled from: ProGuard */
public interface UmengDialogButtonListener {
    void onClick(int i);
}
