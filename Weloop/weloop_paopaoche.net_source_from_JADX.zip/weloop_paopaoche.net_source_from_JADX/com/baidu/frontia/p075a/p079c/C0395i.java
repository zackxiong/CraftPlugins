package com.baidu.frontia.p075a.p079c;

import java.security.cert.X509Certificate;
import javax.net.ssl.X509TrustManager;

/* renamed from: com.baidu.frontia.a.c.i */
class C0395i implements X509TrustManager {
    final /* synthetic */ C0394h f3649a;

    C0395i(C0394h c0394h) {
        this.f3649a = c0394h;
    }

    public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
    }

    public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
    }

    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }
}
