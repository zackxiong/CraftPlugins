package com.baidu.frontia.module.deeplink;

import com.baidu.android.p062a.p063a.C0160a;
import com.baidu.android.p062a.p063a.C0161b;

/* renamed from: com.baidu.frontia.module.deeplink.d */
public interface C0407d {
    void execute(C0160a c0160a, C0161b c0161b);
}
