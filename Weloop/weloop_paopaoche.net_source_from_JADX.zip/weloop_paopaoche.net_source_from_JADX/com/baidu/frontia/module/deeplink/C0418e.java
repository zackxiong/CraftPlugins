package com.baidu.frontia.module.deeplink;

/* renamed from: com.baidu.frontia.module.deeplink.e */
public interface C0418e {
    void m5416a(int i, String str);
}
