package com.baidu.platform.comjni.p089a.p090a;

/* renamed from: com.baidu.platform.comjni.a.a.b */
public class C0641b {
}
