package com.baidu.platform.comjni.p089a.p090a;

/* renamed from: com.baidu.platform.comjni.a.a.a */
public class C0640a {
    private int f4901a;
    private C0641b f4902b;

    public C0640a() {
        this.f4901a = 0;
        this.f4902b = null;
        this.f4902b = new C0641b();
    }
}
