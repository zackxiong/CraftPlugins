package com.baidu.platform.comjni.map.basemap;

import android.os.Bundle;

/* renamed from: com.baidu.platform.comjni.map.basemap.b */
public interface C0619b {
    int m6502a(Bundle bundle, int i, int i2, Bundle bundle2);

    boolean m6503a(int i);
}
