package com.baidu.platform.comapi.p087b;

import com.baidu.platform.comapi.p086a.C0597c;

/* renamed from: com.baidu.platform.comapi.b.a */
public class C0599a {
    public String f4677a;
    public String f4678b;
    public C0597c f4679c;
    public String f4680d;
    public String f4681e;
    public String f4682f;
    public int f4683g;
    public String f4684h;
    public boolean f4685i;
    public String f4686j;
}
