package com.baidu.platform.comapi.p086a;

import java.util.ArrayList;

/* renamed from: com.baidu.platform.comapi.a.a */
public class C0595a {
    public int f4668a;
    public C0597c f4669b;
    public C0597c f4670c;
    public ArrayList<ArrayList<C0597c>> f4671d;
}
