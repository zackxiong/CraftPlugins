package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.a */
public class C0614a extends C0608b {
    public C0614a() {
        this.c = 10;
        this.b = "heatmap";
        this.d = 180000;
    }
}
