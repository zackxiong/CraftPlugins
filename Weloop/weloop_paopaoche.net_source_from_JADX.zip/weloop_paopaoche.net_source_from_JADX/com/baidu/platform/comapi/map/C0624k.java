package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.k */
public class C0624k extends C0611C {
    public C0624k() {
        this.c = 6;
        this.b = "tile";
        this.d = 500;
        this.g = 89076;
    }
}
