package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.u */
public interface C0576u {
    void m6353a(int i, int i2);
}
