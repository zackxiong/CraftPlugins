package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.n */
public class C0626n extends C0608b {
    public C0626n() {
        this.c = 10;
        this.b = "its";
        this.d = 180000;
    }
}
