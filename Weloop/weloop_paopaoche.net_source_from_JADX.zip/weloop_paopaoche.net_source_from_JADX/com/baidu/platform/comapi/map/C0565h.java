package com.baidu.platform.comapi.map;

import android.graphics.Bitmap;
import android.view.MotionEvent;
import com.baidu.platform.comapi.p086a.C0596b;
import javax.microedition.khronos.opengles.GL10;

/* renamed from: com.baidu.platform.comapi.map.h */
public interface C0565h {
    void m6284a();

    void m6285a(Bitmap bitmap);

    void m6286a(MotionEvent motionEvent);

    void m6287a(C0596b c0596b);

    void m6288a(C0639z c0639z);

    void m6289a(String str);

    void m6290a(GL10 gl10, C0639z c0639z);

    void m6291b();

    void m6292b(C0596b c0596b);

    void m6293b(C0639z c0639z);

    boolean m6294b(String str);

    void m6295c();

    void m6296c(C0596b c0596b);

    void m6297c(C0639z c0639z);

    void m6298d();

    void m6299d(C0596b c0596b);

    void m6300e();

    void m6301e(C0596b c0596b);
}
