package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.x */
public enum C0635x {
    DEFAULT(1),
    INDOOR(2),
    STREET(3);
    
    private final int f4859d;

    private C0635x(int i) {
        this.f4859d = i;
    }
}
