package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.d */
public class C0616d extends C0611C {
    public C0616d() {
        this.c = 0;
        this.b = "compass";
        this.d = 0;
        this.g = 20;
    }
}
