package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.j */
public class C0623j extends C0612D {
    public C0623j() {
        this.b = "android_ground";
    }
}
