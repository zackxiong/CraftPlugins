package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.e */
public enum C0617e {
    logo,
    popup,
    marker,
    ground,
    text,
    arc,
    dot,
    circle,
    polyline,
    polygon
}
