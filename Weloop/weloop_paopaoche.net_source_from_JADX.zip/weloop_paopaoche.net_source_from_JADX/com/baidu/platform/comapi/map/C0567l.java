package com.baidu.platform.comapi.map;

import android.os.Bundle;

/* renamed from: com.baidu.platform.comapi.map.l */
public interface C0567l {
    Bundle m6320a(int i, int i2, int i3);
}
