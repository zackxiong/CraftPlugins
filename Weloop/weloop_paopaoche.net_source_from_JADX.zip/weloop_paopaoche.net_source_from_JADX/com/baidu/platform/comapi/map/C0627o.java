package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.o */
public class C0627o extends C0608b {
    public C0627o() {
        this.c = 2;
        this.b = "info_window";
        this.d = 0;
    }
}
