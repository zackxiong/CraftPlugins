package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.y */
public final class C0636y {
    C0639z f4860a;
    boolean f4861b;
    int f4862c;
    boolean f4863d;
    boolean f4864e;
    boolean f4865f;
    boolean f4866g;

    public C0636y() {
        this.f4860a = new C0639z();
        this.f4861b = true;
        this.f4862c = 1;
        this.f4863d = true;
        this.f4864e = true;
        this.f4865f = true;
        this.f4866g = true;
    }

    public C0636y m6609a(int i) {
        this.f4862c = i;
        return this;
    }

    public C0636y m6610a(C0639z c0639z) {
        this.f4860a = c0639z;
        return this;
    }

    public C0636y m6611a(boolean z) {
        this.f4861b = z;
        return this;
    }

    public C0636y m6612b(boolean z) {
        this.f4863d = z;
        return this;
    }

    public C0636y m6613c(boolean z) {
        this.f4864e = z;
        return this;
    }

    public C0636y m6614d(boolean z) {
        this.f4865f = z;
        return this;
    }

    public C0636y m6615e(boolean z) {
        this.f4866g = z;
        return this;
    }
}
