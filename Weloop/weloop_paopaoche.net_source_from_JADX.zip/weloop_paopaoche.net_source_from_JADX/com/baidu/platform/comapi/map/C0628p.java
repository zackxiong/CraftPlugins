package com.baidu.platform.comapi.map;

import java.util.ArrayList;

/* renamed from: com.baidu.platform.comapi.map.p */
public class C0628p {
    public int f4829a;
    public String f4830b;
    public int f4831c;
    public int f4832d;
    public ArrayList<C0628p> f4833e;

    public ArrayList<C0628p> m6583a() {
        return this.f4833e;
    }

    void m6584a(ArrayList<C0628p> arrayList) {
        this.f4833e = arrayList;
    }
}
