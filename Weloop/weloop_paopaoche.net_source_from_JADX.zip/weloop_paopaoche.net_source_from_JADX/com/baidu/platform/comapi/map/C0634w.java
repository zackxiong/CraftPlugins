package com.baidu.platform.comapi.map;

import com.baidu.location.LocationClientOption;

/* renamed from: com.baidu.platform.comapi.map.w */
public class C0634w extends C0611C {
    public C0634w() {
        this.c = 8;
        this.b = "location";
        this.d = LocationClientOption.MIN_SCAN_SPAN;
        this.g = 7;
    }
}
