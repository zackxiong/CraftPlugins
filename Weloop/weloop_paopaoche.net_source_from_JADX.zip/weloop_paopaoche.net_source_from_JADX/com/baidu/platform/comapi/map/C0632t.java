package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.t */
public class C0632t {
    public C0631s f4852a;

    public C0631s m6604a() {
        return this.f4852a;
    }

    void m6605a(C0631s c0631s) {
        this.f4852a = c0631s;
    }
}
