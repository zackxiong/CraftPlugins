package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.m */
public class C0625m extends C0608b {
    public C0625m() {
        this.c = 10;
        this.b = "itsevent";
        this.d = 180000;
    }
}
