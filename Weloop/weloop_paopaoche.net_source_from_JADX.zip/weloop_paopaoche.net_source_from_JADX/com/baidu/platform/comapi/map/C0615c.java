package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.c */
public class C0615c extends C0608b {
    public C0615c() {
        this.c = 6;
        this.b = "map";
        this.d = 500;
    }
}
