package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.D */
public class C0612D extends C0608b {
    public C0612D() {
        this.c = 2;
        this.b = "android_sdk";
        this.d = 0;
    }
}
