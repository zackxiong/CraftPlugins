package com.baidu.platform.comapi.map;

import com.baidu.platform.comapi.p086a.C0597c;

/* renamed from: com.baidu.platform.comapi.map.s */
public class C0631s {
    public int f4840a;
    public String f4841b;
    public String f4842c;
    public String f4843d;
    public int f4844e;
    public int f4845f;
    public C0597c f4846g;
    public int f4847h;
    public int f4848i;
    public boolean f4849j;
    public int f4850k;
    public int f4851l;
}
