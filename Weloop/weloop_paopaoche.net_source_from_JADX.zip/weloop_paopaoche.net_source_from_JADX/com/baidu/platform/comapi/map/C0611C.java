package com.baidu.platform.comapi.map;

import android.os.Bundle;

/* renamed from: com.baidu.platform.comapi.map.C */
public class C0611C extends C0608b {
    private static final String f4748h;
    Bundle f4749e;
    String f4750f;
    int f4751g;

    static {
        f4748h = C0611C.class.getSimpleName();
    }

    public String m6494a() {
        return this.f4750f;
    }

    public void m6495a(Bundle bundle) {
        this.f4749e = bundle;
    }

    public void m6496a(String str) {
        this.f4750f = str;
    }

    public Bundle m6497b() {
        return this.f4749e;
    }
}
