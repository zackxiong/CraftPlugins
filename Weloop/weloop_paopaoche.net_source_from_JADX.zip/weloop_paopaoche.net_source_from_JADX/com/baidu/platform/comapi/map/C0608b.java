package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.b */
public abstract class C0608b {
    int f4743a;
    String f4744b;
    int f4745c;
    int f4746d;
}
