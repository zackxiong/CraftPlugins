package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.A */
public class C0609A extends C0608b {
    public C0609A() {
        this.c = 4;
        this.b = "mappoi";
        this.d = 100;
    }
}
