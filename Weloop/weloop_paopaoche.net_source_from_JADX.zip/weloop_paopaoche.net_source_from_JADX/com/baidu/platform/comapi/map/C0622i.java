package com.baidu.platform.comapi.map;

/* renamed from: com.baidu.platform.comapi.map.i */
public class C0622i extends C0612D {
    public C0622i() {
        this.b = "geometry";
    }
}
