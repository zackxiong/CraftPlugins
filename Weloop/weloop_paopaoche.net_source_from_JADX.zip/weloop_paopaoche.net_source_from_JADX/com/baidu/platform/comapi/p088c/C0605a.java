package com.baidu.platform.comapi.p088c;

import android.util.Log;

/* renamed from: com.baidu.platform.comapi.c.a */
public class C0605a {
    public static void m6463a(String str, String str2) {
    }

    public static void m6464b(String str, String str2) {
        Log.w(str, str2);
    }
}
