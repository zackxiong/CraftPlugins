package com.baidu.mapapi.navi;

public class BaiduMapAppNotSupportNaviException extends RuntimeException {
    public BaiduMapAppNotSupportNaviException(String str) {
        super(str);
    }
}
