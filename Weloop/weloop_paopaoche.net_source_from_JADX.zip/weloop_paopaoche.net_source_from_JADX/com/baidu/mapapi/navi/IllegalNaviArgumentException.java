package com.baidu.mapapi.navi;

public class IllegalNaviArgumentException extends RuntimeException {
    public IllegalNaviArgumentException(String str) {
        super(str);
    }
}
