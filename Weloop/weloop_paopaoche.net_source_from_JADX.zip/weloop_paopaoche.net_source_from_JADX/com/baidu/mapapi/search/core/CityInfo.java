package com.baidu.mapapi.search.core;

public class CityInfo {
    public String city;
    public int num;
}
