package com.baidu.mapapi.utils.route;

public class IllegalRoutePlanArgumentException extends RuntimeException {
    public IllegalRoutePlanArgumentException(String str) {
        super(str);
    }
}
