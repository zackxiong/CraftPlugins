package com.baidu.mapapi.utils.poi;

public class IllegalPoiSearchArgumentException extends RuntimeException {
    public IllegalPoiSearchArgumentException(String str) {
        super(str);
    }
}
