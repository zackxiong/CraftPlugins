package com.baidu.lbsapi.auth;

import com.baidu.android.pushservice.db.LightAppTableDefine;
import org.json.JSONException;
import org.json.JSONObject;

class ErrorMessage {
    ErrorMessage() {
    }

    static String m5444a(String str) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("status", -1);
            jSONObject.put(LightAppTableDefine.DB_TABLE_MESSAGE, str);
        } catch (JSONException e) {
        }
        return jSONObject.toString();
    }
}
