package com.baidu.lbsapi.auth;

/* renamed from: com.baidu.lbsapi.auth.g */
class C0438g implements Runnable {
    final /* synthetic */ C0437f f3747a;

    C0438g(C0437f c0437f) {
        this.f3747a = c0437f;
    }

    public void run() {
        this.f3747a.m5479a(this.f3747a.f3745e);
    }
}
