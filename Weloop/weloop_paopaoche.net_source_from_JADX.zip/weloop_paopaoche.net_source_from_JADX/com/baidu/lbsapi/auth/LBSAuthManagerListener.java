package com.baidu.lbsapi.auth;

public interface LBSAuthManagerListener {
    void onAuthResult(int i, String str);
}
