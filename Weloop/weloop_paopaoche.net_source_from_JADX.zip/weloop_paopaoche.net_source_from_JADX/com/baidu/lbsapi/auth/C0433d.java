package com.baidu.lbsapi.auth;

/* renamed from: com.baidu.lbsapi.auth.d */
class C0433d implements Runnable {
    final /* synthetic */ C0432c f3736a;

    C0433d(C0432c c0432c) {
        this.f3736a = c0432c;
    }

    public void run() {
        this.f3736a.m5465a(this.f3736a.f3733d, this.f3736a.f3734e);
    }
}
