package com.baidu.android.pushservice.p071e;

import java.util.HashMap;

/* renamed from: com.baidu.android.pushservice.e.o */
public interface C0251o {
    void m4778a(int i, HashMap<String, String> hashMap);
}
