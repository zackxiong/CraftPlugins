package com.baidu.android.pushservice.p071e;

/* renamed from: com.baidu.android.pushservice.e.a */
public interface C0246a {
    void m4635a(int i);

    void m4636a(int i, String str);

    void m4637a(int i, String str, boolean z);

    void m4638a(boolean z);

    void m4639a(boolean z, boolean z2);

    void m4640b(int i);

    void m4641b(int i, String str);

    void m4642c(int i);

    void m4643c(int i, String str);

    void m4644d(int i);

    void m4645d(int i, String str);

    void m4646e(int i);

    void m4647e(int i, String str);

    void m4648f(int i, String str);

    void m4649g(int i, String str);

    void m4650h(int i, String str);

    void m4651i(int i, String str);

    void m4652j(int i, String str);
}
