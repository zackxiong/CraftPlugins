package com.baidu.android.pushservice.p065a.p066a;

import com.baidu.android.pushservice.p065a.p066a.C0170a.C0169b;
import java.security.cert.X509Certificate;
import javax.net.ssl.X509TrustManager;

/* renamed from: com.baidu.android.pushservice.a.a.b */
class C0171b implements X509TrustManager {
    final /* synthetic */ C0169b f2894a;

    C0171b(C0169b c0169b) {
        this.f2894a = c0169b;
    }

    public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
    }

    public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
    }

    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }
}
