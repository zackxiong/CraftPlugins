package com.baidu.android.pushservice.p065a.p067b;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;

/* renamed from: com.baidu.android.pushservice.a.b.f */
public interface C0181f {
    Notification m4266a();

    void m4267a(int i);

    void m4268a(long j);

    void m4269a(PendingIntent pendingIntent);

    void m4270a(Intent intent);

    void m4271a(String str);

    void m4272b(int i);

    void m4273b(Bitmap bitmap);

    void m4274b(String str);

    void m4275c(int i);

    void m4276c(Bitmap bitmap);
}
