package com.baidu.android.pushservice.p065a.p066a;

import android.graphics.Bitmap;

/* renamed from: com.baidu.android.pushservice.a.a.d */
interface C0172d {
    void m4242a(String str, Bitmap bitmap);
}
