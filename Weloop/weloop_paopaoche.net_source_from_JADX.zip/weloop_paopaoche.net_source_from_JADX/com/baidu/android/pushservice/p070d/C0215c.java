package com.baidu.android.pushservice.p070d;

import android.content.Context;
import com.baidu.android.pushservice.ad;

/* renamed from: com.baidu.android.pushservice.d.c */
public abstract class C0215c extends C0214a {
    public C0215c(C0226l c0226l, Context context) {
        super(c0226l, context);
    }

    public boolean m4512b() {
        this.c += ad.m4377a().m4382c();
        return super.m4511b();
    }
}
