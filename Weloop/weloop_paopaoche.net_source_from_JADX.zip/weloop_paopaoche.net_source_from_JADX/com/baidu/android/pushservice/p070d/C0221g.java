package com.baidu.android.pushservice.p070d;

/* renamed from: com.baidu.android.pushservice.d.g */
public class C0221g {
    private String f3019a;
    private String f3020b;

    public C0221g(String str, String str2) {
        this.f3019a = str;
        this.f3020b = str2;
    }

    public String m4534a() {
        return this.f3019a;
    }

    public String m4535b() {
        return this.f3020b;
    }

    public String toString() {
        return "BindCache [mApiKey=" + this.f3019a + ", mContent=" + this.f3020b + "]";
    }
}
