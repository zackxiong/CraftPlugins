package com.baidu.android.pushservice.p070d;

import android.content.Context;
import com.baidu.frontia.p075a.p077b.p078a.C0385a;
import com.umeng.update.ProGuard;

/* renamed from: com.baidu.android.pushservice.d.e */
public abstract class C0217e extends C0214a {
    public C0217e(C0226l c0226l, Context context) {
        super(c0226l, context);
    }

    public boolean m4515b() {
        C0385a.m5308a("SendApiProcessor", "networkConnect");
        this.c += ProGuard.f5477e;
        return super.m4511b();
    }
}
