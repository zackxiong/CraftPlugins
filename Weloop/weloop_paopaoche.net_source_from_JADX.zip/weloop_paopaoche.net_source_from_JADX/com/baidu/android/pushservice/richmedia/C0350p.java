package com.baidu.android.pushservice.richmedia;

import com.baidu.android.pushservice.richmedia.C0347n.C0346a;

/* renamed from: com.baidu.android.pushservice.richmedia.p */
public class C0350p {
    public C0346a f3476a;
    public int f3477b;
    public int f3478c;
    public C0347n f3479d;
    public String f3480e;
}
