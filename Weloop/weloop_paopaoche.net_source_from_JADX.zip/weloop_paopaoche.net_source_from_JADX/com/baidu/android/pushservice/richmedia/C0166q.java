package com.baidu.android.pushservice.richmedia;

/* renamed from: com.baidu.android.pushservice.richmedia.q */
public interface C0166q {
    void m4194a(C0334b c0334b);

    void m4195a(C0334b c0334b, C0345m c0345m);

    void m4196a(C0334b c0334b, C0350p c0350p);

    void m4197a(C0334b c0334b, Throwable th);

    void m4198b(C0334b c0334b);
}
