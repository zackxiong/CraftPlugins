package com.baidu.android.pushservice.richmedia;

import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.webkit.WebView;

/* renamed from: com.baidu.android.pushservice.richmedia.j */
class C0342j extends WebChromeClient {
    final /* synthetic */ MediaViewActivity f3452a;

    C0342j(MediaViewActivity mediaViewActivity) {
        this.f3452a = mediaViewActivity;
    }

    public void onHideCustomView() {
    }

    public void onProgressChanged(WebView webView, int i) {
    }

    public void onShowCustomView(View view, CustomViewCallback customViewCallback) {
    }
}
