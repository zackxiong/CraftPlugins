package com.baidu.android.pushservice.richmedia;

import android.view.View;
import android.view.View.OnClickListener;

/* renamed from: com.baidu.android.pushservice.richmedia.c */
class C0335c implements OnClickListener {
    final /* synthetic */ MediaListActivity f3444a;

    C0335c(MediaListActivity mediaListActivity) {
        this.f3444a = mediaListActivity;
    }

    public void onClick(View view) {
        this.f3444a.finish();
    }
}
