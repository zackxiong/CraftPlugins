package com.baidu.android.pushservice.richmedia;

/* renamed from: com.baidu.android.pushservice.richmedia.m */
public class C0345m {
    public long f3457a;
    public long f3458b;
}
