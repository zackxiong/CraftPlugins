package com.baidu.android.pushservice.richmedia;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

/* renamed from: com.baidu.android.pushservice.richmedia.f */
class C0338f implements OnClickListener {
    final /* synthetic */ C0337e f3447a;

    C0338f(C0337e c0337e) {
        this.f3447a = c0337e;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
    }
}
