package com.baidu.android.pushservice.p072f;

/* renamed from: com.baidu.android.pushservice.f.p */
public class C0267p extends C0266e {
    public static int f3188m;
    public static int f3189n;
    public static int f3190o;
    public static int f3191p;
    public static int f3192q;
    public static String f3193r;
    public static String f3194s;
    public static String f3195t;
    public static String f3196u;

    static {
        f3188m = -1;
        f3189n = 0;
        f3190o = 1;
        f3191p = 2;
        f3192q = 3;
        f3193r = "01";
        f3194s = "02";
        f3195t = "03";
        f3196u = "04";
    }

    public C0267p(C0267p c0267p) {
        this.g = c0267p.g;
        this.h = c0267p.h;
        this.j = c0267p.j;
        this.i = c0267p.i;
    }

    public C0267p(String str, long j, String str2, int i, String str3) {
        this.g = str;
        this.h = j;
        this.i = str2;
        this.j = i;
        this.k = str3;
    }

    public C0267p(String str, long j, String str2, String str3) {
        this.g = str;
        this.h = j;
        this.i = str2;
        this.k = str3;
    }
}
