package com.baidu.android.pushservice.p072f;

/* renamed from: com.baidu.android.pushservice.f.x */
public class C0288x {
    private int f3281a;
    private String f3282b;
    private long f3283c;
    private String f3284d;

    public C0287w m4957a() {
        C0287w c0287w = new C0287w();
        c0287w.f = this.f3281a;
        c0287w.g = this.f3282b;
        c0287w.f3280a = this.f3284d;
        c0287w.h = this.f3283c;
        return c0287w;
    }

    public void m4958a(int i) {
        this.f3281a = i;
    }

    public void m4959a(long j) {
        this.f3283c = j;
    }

    public void m4960a(String str) {
        this.f3282b = str;
    }

    public void m4961b(String str) {
        this.f3284d = str;
    }
}
