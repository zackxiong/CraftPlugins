package com.baidu.android.pushservice.p072f;

/* renamed from: com.baidu.android.pushservice.f.e */
public abstract class C0266e {
    public int f3181f;
    public String f3182g;
    public long f3183h;
    public String f3184i;
    public int f3185j;
    public String f3186k;
    public String f3187l;

    public C0266e() {
        this.f3186k = "0";
        this.f3187l = "0";
    }
}
