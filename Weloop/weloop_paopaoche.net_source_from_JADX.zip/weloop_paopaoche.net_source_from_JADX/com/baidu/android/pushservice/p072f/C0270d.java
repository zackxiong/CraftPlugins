package com.baidu.android.pushservice.p072f;

/* renamed from: com.baidu.android.pushservice.f.d */
public class C0270d {
    private String f3205a;
    private String f3206b;
    private String f3207c;
    private String f3208d;
    private String f3209e;
    private String f3210f;
    private int f3211g;
    private String f3212h;
    private int f3213i;

    public C0270d() {
        this.f3211g = -1;
        this.f3213i = -1;
    }

    public C0270d(String str) {
        this.f3211g = -1;
        this.f3213i = -1;
        this.f3205a = str;
    }

    public String m4838a() {
        return this.f3205a;
    }

    public void m4839a(int i) {
        this.f3211g = i;
    }

    public void m4840a(String str) {
        this.f3205a = str;
    }

    public String m4841b() {
        return this.f3206b;
    }

    public void m4842b(int i) {
        this.f3213i = i;
    }

    public void m4843b(String str) {
        this.f3206b = str;
    }

    public String m4844c() {
        return this.f3207c;
    }

    public void m4845c(String str) {
        this.f3207c = str;
    }

    public String m4846d() {
        return this.f3208d;
    }

    public void m4847d(String str) {
        this.f3208d = str;
    }

    public String m4848e() {
        return this.f3209e;
    }

    public void m4849e(String str) {
        this.f3209e = str;
    }

    public String m4850f() {
        return this.f3210f;
    }

    public void m4851f(String str) {
        this.f3210f = str;
    }

    public int m4852g() {
        return this.f3211g;
    }

    public void m4853g(String str) {
        this.f3212h = str;
    }

    public String m4854h() {
        return this.f3212h;
    }

    public int m4855i() {
        return this.f3213i;
    }
}
