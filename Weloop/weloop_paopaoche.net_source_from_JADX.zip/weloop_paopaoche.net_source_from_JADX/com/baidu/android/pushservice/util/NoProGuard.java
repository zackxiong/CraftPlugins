package com.baidu.android.pushservice.util;

public interface NoProGuard {
}
