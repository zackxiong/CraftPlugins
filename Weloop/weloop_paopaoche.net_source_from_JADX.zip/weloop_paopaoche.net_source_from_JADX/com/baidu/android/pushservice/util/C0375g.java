package com.baidu.android.pushservice.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* renamed from: com.baidu.android.pushservice.util.g */
final class C0375g extends BroadcastReceiver {
    C0375g() {
    }

    public void onReceive(Context context, Intent intent) {
    }
}
