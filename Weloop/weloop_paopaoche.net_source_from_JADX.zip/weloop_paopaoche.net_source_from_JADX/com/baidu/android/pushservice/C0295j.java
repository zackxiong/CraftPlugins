package com.baidu.android.pushservice;

/* renamed from: com.baidu.android.pushservice.j */
class C0295j implements Runnable {
    final /* synthetic */ C0293h f3323a;

    C0295j(C0293h c0293h) {
        this.f3323a = c0293h;
    }

    public void run() {
        this.f3323a.m4989e();
    }
}
