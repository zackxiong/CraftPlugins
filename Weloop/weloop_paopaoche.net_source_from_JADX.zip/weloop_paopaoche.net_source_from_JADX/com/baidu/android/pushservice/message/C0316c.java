package com.baidu.android.pushservice.message;

import android.content.Context;

/* renamed from: com.baidu.android.pushservice.message.c */
public abstract class C0316c {
    protected Context f3362a;

    public C0316c(Context context) {
        this.f3362a = context;
    }

    public abstract int m5048a(C0319e c0319e);
}
