package com.baidu.android.pushservice.p069c;

/* renamed from: com.baidu.android.pushservice.c.k */
public class C0211k extends C0200a {
    public C0211k(String str) {
        super(str);
    }

    public String toString() {
        return "WebAppClient [mAppId=" + this.a + ", mApiKey=" + this.b + "]";
    }
}
