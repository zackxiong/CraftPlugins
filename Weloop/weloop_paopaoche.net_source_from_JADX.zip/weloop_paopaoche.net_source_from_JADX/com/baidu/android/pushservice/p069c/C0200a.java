package com.baidu.android.pushservice.p069c;

/* renamed from: com.baidu.android.pushservice.c.a */
public class C0200a {
    protected String f2961a;
    protected String f2962b;
    protected String f2963c;
    protected int f2964d;

    public C0200a(String str) {
        this.f2962b = str;
        this.f2961a = "";
    }

    public C0200a(String str, String str2) {
        this(str);
        this.f2963c = str2;
    }

    public String m4439a() {
        return this.f2961a;
    }

    public void m4440a(int i) {
        this.f2964d = i;
    }

    public void m4441a(String str) {
        this.f2961a = str;
    }

    public String m4442b() {
        return this.f2962b;
    }

    public void m4443b(String str) {
        this.f2963c = str;
    }

    public String m4444c() {
        return this.f2963c;
    }

    public int m4445d() {
        return this.f2964d;
    }
}
