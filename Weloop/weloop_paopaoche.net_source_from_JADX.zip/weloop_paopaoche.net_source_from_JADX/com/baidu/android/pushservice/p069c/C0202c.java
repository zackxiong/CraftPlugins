package com.baidu.android.pushservice.p069c;

/* renamed from: com.baidu.android.pushservice.c.c */
public enum C0202c {
    PUSH_CLIENT,
    SDK_CLIENT,
    WEBAPP_CLIENT,
    LIGHT_APP_CLIENT_NEW,
    UNKNOWN_CLIENT
}
