package com.baidu.android.pushservice.p069c;

/* renamed from: com.baidu.android.pushservice.c.i */
public class C0209i extends C0200a {
    public C0209i(String str, String str2) {
        super(str, str2);
    }

    public String toString() {
        return "SDKClient [mAppId=" + this.a + ", mApiKey=" + this.b + ", mPkgName=" + this.c + ", mSDKVersion=" + this.d + "]";
    }
}
