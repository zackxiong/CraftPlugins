package com.baidu.android.pushservice.p069c;

/* renamed from: com.baidu.android.pushservice.c.f */
public class C0206f extends C0200a {
    public C0206f(String str) {
        super(str);
    }

    public String toString() {
        return "LightAppClient [mAppId=" + this.a + ", mApiKey=" + this.b + "]";
    }
}
