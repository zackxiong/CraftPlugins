package com.baidu.android.pushservice.p069c;

/* renamed from: com.baidu.android.pushservice.c.h */
public class C0208h extends C0200a {
    public String f2984e;

    public C0208h() {
        this.f2984e = "";
    }

    public String toString() {
        return "mPackageName: " + this.c + ", mAppId: " + this.a + ", mUserId: " + this.f2984e;
    }
}
