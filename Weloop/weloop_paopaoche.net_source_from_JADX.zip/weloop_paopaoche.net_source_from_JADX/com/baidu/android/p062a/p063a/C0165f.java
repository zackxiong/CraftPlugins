package com.baidu.android.p062a.p063a;

/* renamed from: com.baidu.android.a.a.f */
class C0165f implements Runnable {
    final /* synthetic */ C0164e f2874a;

    C0165f(C0164e c0164e) {
        this.f2874a = c0164e;
    }

    public void run() {
        try {
            this.f2874a.m4169c();
        } catch (Exception e) {
            this.f2874a.f2869a = false;
        }
        this.f2874a.m4170d();
    }
}
