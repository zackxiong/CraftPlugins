package com.baidu.android.p062a.p063a;

/* renamed from: com.baidu.android.a.a.d */
public interface C0163d {
    void m4163a(C0162c c0162c);

    void m4164a(C0162c c0162c, Exception exception);

    void m4165b(C0162c c0162c);
}
